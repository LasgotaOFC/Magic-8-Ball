import os
import time
import random
# Imports

def start_error404():
    while True:
        print('=' * 100)
        print(' Magic 8 Ball '.center(100, '-'))
        print('=' * 100)
        print('!You should not take any advice from this fictitious bot seriously!')
        answer = input('Answer: ')
        response = random.choice([' Yes, obviously ' , ' Positive ' , ' Afirmative ',
                                ' No, obviously ' , ' Negative ' , ' Negative '])
        print(response.center(100 , '-'))
        input('For ask again, press any key!')
        os.system("cls")

start_error404()